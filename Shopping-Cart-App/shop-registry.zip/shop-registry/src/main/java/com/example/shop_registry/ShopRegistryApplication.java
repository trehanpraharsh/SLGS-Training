package com.example.shop_registry;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShopRegistryApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShopRegistryApplication.class, args);
	}

}
