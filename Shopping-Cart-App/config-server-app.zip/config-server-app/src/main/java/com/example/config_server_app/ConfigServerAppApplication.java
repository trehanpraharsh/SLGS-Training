package com.example.config_server_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConfigServerAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConfigServerAppApplication.class, args);
	}

}
