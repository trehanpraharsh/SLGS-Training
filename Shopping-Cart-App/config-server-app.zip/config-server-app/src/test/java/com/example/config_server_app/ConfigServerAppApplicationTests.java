package com.example.config_server_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfigServerAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
